<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class coba extends CI_Controller {
	public function nelsen()
	{
       $query['query'] = $this->db->get('login')->result();

        $this->load->view('view_data', $query);
	}
}


