<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class signup extends CI_Controller {

	public function index()
	{
		echo"<h1>Halaman Daftar</h1>";
		echo"<h1>Profil</h1>";
        
	}
}
