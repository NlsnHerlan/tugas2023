<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Ini Data</h1>

        <table border="2px" >
        <tr>
            <th>ID Soal</th>
            <th>Nama</th>
            <th>Jurusan</th>
        </tr>
                <?php foreach ($query as $query) { ?>
            <tr>
                <td> <?= $query->nik ?></td>
                <td> <?= $query->nama ?></td>
                <td> <?= $query->jurusan ?></td>
            </tr>
            <?php } ?>
        </table>
</body>
</html>