<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Peduli Diri</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
</head>
<body>
    <style>
        .foto{
            background-image: url("https://img.inews.co.id/files/inews_new/2021/10/05/universitas_negeri_padang_sumatera_barat.jpg");
            background-repeat:no-repeat;
            background-size: cover;
            background-position:center;
            height:400px;
            
        }

      
    </style>
<link rel="stylesheet" href="style.css">
<nav>
    <div class="hotel">
            <div class="logo">
            </div>
    </div>
    </nav>
<div class="container" >
        <div class="d-flex justify-content-between text-center foto" style="background-color:aliceblue;"
            align="right" border="5" class="float-right">
            <div  class=" text-center h-95 mt-5">
                <img src="https://rekreartive.com/wp-content/uploads/2018/11/Logo-UPN-Universitas-Negeri-Padang-PNG.png" alt="" height="80">
            </div>
        </div>
    </span>
  
</body>
</html>