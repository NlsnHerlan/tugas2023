<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    
    <body class="h-100 mt-5" >
     <div class="container text-center h-95 d-flex">
         <div class="card text-center my-auto mx-auto" style="width: 25rem;" >
             <h1 class="card-header"> Buat Akun</h1>
             <br>
             <div class="card-body">
                 <form action="proses_login.php" method="POST">
                     <div class="mb-4">
                        <input class="px-3" placeholder="Masukan NIS" type="text" name="nis" required>
                     </div>
                         
                     <div class="mb-4">
                        <input  class="px-3" placeholder="Masukan Nama" type="text" name="nama" required>
                     </div>

                     <div class="mb-4">
                        <input  class="px-3" placeholder="Nama Jurusan" type="text" name="jurusan" required>
                     </div>
                         
                         <button class="btn btn-primary btn-login">Daftar</button>
                 </form>
             </div>
             <div class="card-body" style="background-color:#AEA4A8">
                 <p class="card-text">Sudah punya akun?Klik
                 <a href="Login" class="link">Login</a></p>
 
             </div>
         </div>
        </div>
</body>
</html>

